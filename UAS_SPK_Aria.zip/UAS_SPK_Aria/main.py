from http import HTTPStatus
from flask import Flask, request, abort
from flask_restful import Resource, Api
from models import hp as hpModel
from engine import engine
from sqlalchemy import select
from sqlalchemy.orm import Session
from tabulate import tabulate

session = Session(engine)

app = Flask(__name__)
api = Api(app)


class BaseMethod():

    def __init__(self):
        self.raw_weight = {'merek': 8, 'ram':5,'rom': 6, 
                           'baterai': 4, 'harga': 9}

    @property
    def weight(self):
        total_weight = sum(self.raw_weight.values())
        return {k: round(v/total_weight, 2) for k, v in self.raw_weight.items()}

    @property
    def data(self):
        query = select(hpModel.no, hpModel.nama_hp, hpModel.merek, hpModel.ram,
                       hpModel.rom, hpModel.baterai, hpModel.harga)
        result = session.execute(query).fetchall()
        print(result)
        return [{'no': hp.no,'nama_hp': hp.nama_hp, 'merek': hp.merek,
                'ram': hp.ram, 'rom': hp.rom, 'baterai': hp.baterai, 'harga': hp.harga} for hp in result]

    @property
    def normalized_data(self):
        # x/max [benefit]
        # min/x [cost]
        nama_hp_values = [] # max
        merek_values = []  # max
        ram_values = []  # max
        rom_values = []  # max
        baterai_values = []  # max
        harga_values = []  # min

        for data in self.data:
            # Nama_hp
            nama_hp_spec = data['nama_hp']
            numeric_values = [int(value.split()[0]) for value in nama_hp_spec.split(
                ',') if value.split()[0].isdigit()]
            max_nama_hp_value = max(numeric_values) if numeric_values else 1
            nama_hp_values.append(max_nama_hp_value)

            # merek
            merek_cleaned = ''.join(
                char for char in data['merek'] if char.isdigit())
            merek_values.append(float(merek_cleaned)
                                if merek_cleaned else 0)  # Convert to float
            
            # ram
            ram_spec = data['ram']
            ram_numeric_values = [int(
                value.split()[0]) for value in ram_spec.split() if value.split()[0].isdigit()]
            max_ram_value = max(
                ram_numeric_values) if ram_numeric_values else 1
            ram_values.append(max_ram_value)

            # rom
            rom_spec = data['rom']
            rom_numeric_values = [float(value.split()[0]) for value in rom_spec.split(
            ) if value.replace('.', '').isdigit()]
            max_rom_value = max(
                rom_numeric_values) if rom_numeric_values else 1
            rom_values.append(max_rom_value)

            # baterai
            baterai_spec = data['baterai']
            baterai_numeric_values = [
                int(value) for value in baterai_spec.split() if value.isdigit()]
            max_baterai_value = max(
                baterai_numeric_values) if baterai_numeric_values else 1
            baterai_values.append(max_baterai_value)

            # harga
            harga_spec = data['harga']
            harga_numeric_values = [
                int(value) for value in harga_spec.split() if value.isdigit()]
            max_harga_value = max(
                harga_numeric_values) if harga_numeric_values else 1
            harga_values.append(max_harga_value)

        return [
    {
        'no': data['no'],
        'nama_hp': nama_hp_value / max(nama_hp_values),
        'merek': min(merek_values) / max(merek_values) if max(merek_values) != 0 else 0,
        'ram': ram_value / max(ram_values),
        'rom': rom_value / max(rom_values),
        'baterai': baterai_value / max(baterai_values),
        'harga': harga_value / max(harga_values),
    }
    for data, nama_hp_value, merek_value, ram_value, rom_value, baterai_value, harga_value
    in zip(self.data, nama_hp_values, merek_values, ram_values, rom_values, baterai_values, harga_values)
]


    def update_weights(self, new_weights):
        self.raw_weight = new_weights


class WeightedProductCalculator(BaseMethod):
    def update_weights(self, new_weights):
        self.raw_weight = new_weights

    @property
    def calculate(self):
        normalized_data = self.normalized_data
        produk = [
            {
                'no': row['no'],
                'produk': row['merek']**self.weight['merek'] *
                row['ram']**self.weight['ram'] *
                row['rom']**self.weight['rom'] *
                row['baterai']**self.weight['baterai'] *
                row['harga']**self.weight['harga'],
                'nama_hp': row.get('nama_hp', '')
            }
            for row in normalized_data
        ]
        sorted_produk = sorted(produk, key=lambda x: x['produk'], reverse=True)
        sorted_data = [
            {
                'ID': product['no'],
                'score': round(product['produk'], 3)
            }
            for product in sorted_produk
        ]
        return sorted_data


class WeightedProduct(Resource):
    def get(self):
        calculator = WeightedProductCalculator()
        result = calculator.calculate
        return sorted(result, key=lambda x: x['score'], reverse=True), HTTPStatus.OK.value

    def post(self):
        new_weights = request.get_json()
        calculator = WeightedProductCalculator()
        calculator.update_weights(new_weights)
        result = calculator.calculate
        return {'hp': sorted(result, key=lambda x: x['score'], reverse=True)}, HTTPStatus.OK.value


class SimpleAdditiveWeightingCalculator(BaseMethod):
    @property
    def calculate(self):
        weight = self.weight
        result = [
            {
                'ID': row['no'],
                'Score': round(row['merek'] * weight['merek'] +
                               row['ram'] * weight['ram'] +
                               row['rom'] * weight['rom'] +
                               row['baterai'] * weight['baterai'] +
                               row['harga'] * weight['harga'], 3)
            }
            for row in self.normalized_data
        ]
        sorted_result = sorted(result, key=lambda x: x['Score'], reverse=True)
        return sorted_result

    def update_weights(self, new_weights):
        self.raw_weight = new_weights


class SimpleAdditiveWeighting(Resource):
    def get(self):
        saw = SimpleAdditiveWeightingCalculator()
        result = saw.calculate
        return sorted(result, key=lambda x: x['Score'], reverse=True), HTTPStatus.OK.value

    def post(self):
        new_weights = request.get_json()
        saw = SimpleAdditiveWeightingCalculator()
        saw.update_weights(new_weights)
        result = saw.calculate
        return {'hp': sorted(result, key=lambda x: x['Score'], reverse=True)}, HTTPStatus.OK.value


class hp(Resource):
    def get_paginated_result(self, url, list, args):
        page_size = int(args.get('page_size', 10))
        page = int(args.get('page', 1))
        page_count = int((len(list) + page_size - 1) / page_size)
        start = (page - 1) * page_size
        end = min(start + page_size, len(list))

        if page < page_count:
            next_page = f'{url}?page={page+1}&page_size={page_size}'
        else:
            next_page = None
        if page > 1:
            prev_page = f'{url}?page={page-1}&page_size={page_size}'
        else:
            prev_page = None

        if page > page_count or page < 1:
            abort(404, description=f'Data Tidak Ditemukan.')
        return {
            'page': page,
            'page_size': page_size,
            'next': next_page,
            'prev': prev_page,
            'Results': list[start:end]
        }

    def get(self):
        query = session.query(hpModel).order_by(hpModel.no)
        result_set = query.all()
        data = [{'no': row.no, 'nama_hp': row.nama_hp, 'merek': row.merek,
                 'ram': row.ram, 'rom': row.rom, 'baterai': row.baterai, 'harga': row.harga}
                for row in result_set]
        return self.get_paginated_result('hp/', data, request.args), 200


api.add_resource(hp, '/hp')
api.add_resource(WeightedProduct, '/wp')
api.add_resource(SimpleAdditiveWeighting, '/saw')

if __name__ == '__main__':
    app.run(port='5005', debug=True)