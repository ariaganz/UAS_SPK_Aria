USER = 'postgres'
PASSWORD = 'aria123'
HOST = 'localhost'
PORT = '5432'
DATABASE_NAME = 'db_hp'

DEV_SCALE = {
    'merek': {
        'Apple': 5,
        'Samsung, OnePlus, Google, Sony': 4, 
        'Xiaomi, Oppo, Asus': 3, 
        'Vivo, Realme': 2, 
        '': 1, 
    },
    'ram': {
        '16 GB': 5, 
        '12 GB': 4, 
        '8 GB': 3, 
        '6 GB': 2, 
        '': 1
    },
    'rom': {
        '256 GB': 5,
        '128 GB': 3,
    },
    'baterai' : {
        '5020 mAh-6000 mAh': 5,
        '4614 mAh': 4,
        '4500 mAh': 3,
        '4000 mAh- 4200 mAh': 2,
        '3095 mAh': 1,
    },
    'harga' : {
        '18.000.000': 5,
        '13900000-16.500.000': 4,
        '10800000-12.000.000': 3,
        '7800000-9.700.000': 2,
        '4.500.000': 1,
    },
}