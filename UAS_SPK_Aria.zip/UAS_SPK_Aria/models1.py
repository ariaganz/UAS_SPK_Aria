from sqlalchemy import Column, String, Integer
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class hp(Base):
    __tablename__ = "tbl_hp"
    no = Column(Integer, primary_key=True)
    nama_hp = Column(String(255))
    merek = Column(String(255))
    ram = Column(String(255))
    rom = Column(String(255))
    baterai = Column(String(255))
    harga = Column(String(255))

    def __init__(self, no, nama_hp, merek, ram, rom, baterai, harga):
        self.no = no
        self.nama_hp = nama_hp
        self.merek = merek
        self.ram = ram
        self.rom = rom
        self.baterai = baterai
        self.harga = harga

    def calculate_score(self, dev_scale):
        score = 0
        score -= self.merek * dev_scale['merek']
        score += self.ram * dev_scale['ram']
        score += self.rom * dev_scale['rom']
        score += self.baterai * dev_scale['baterai']
        score += self.harga * dev_scale['harga']
        return score

    def __repr__(self):
        return f"hp(no={self.no!r}, nama_hp={self.nama_hp!r}, merek={self.merek!r}, ram={self.ram!r}, rom={self.rom!r}, baterai={self.baterai!r}, harga={self.harga!r})"
