from sqlalchemy import String, Integer, Column
from sqlalchemy.orm import declarative_base


Base = declarative_base()

class hp(Base):
    __tablename__ = "tbl_hp"
    no = Column(Integer, primary_key=True)
    nama_hp = Column(String)
    merek = Column(Integer)
    ram = Column(String)
    rom = Column(String)
    baterai = Column(String) 
    harga = Column(String) 

    def __repr__(self):
        return f"hp(type={self.type!r}, nama_hp={self.nama_hp!r}, merek={self.merek!r}, ram={self.ram!r}, rom={self.rom!r}, baterai={self.baterai!r}, harga={self.harga!r}, benefit={self.benefit!r})"