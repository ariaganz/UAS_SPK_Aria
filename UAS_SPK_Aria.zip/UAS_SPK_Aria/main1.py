import sys
from colorama import Fore, Style
from models import Base, hp
from engine import engine
from tabulate import tabulate

from sqlalchemy import select
from sqlalchemy.orm import Session
from settings import DEV_SCALE

session = Session(engine)


def create_table():
    Base.metadata.create_all(engine)
    print(f'{Fore.GREEN}[Success]: {Style.RESET_ALL}Database has created!')


def review_data():
    query = select(Helm)
    for phone in session.scalars(query):
        print(hp)


class BaseMethod():

    def __init__(self):
        # 1-5
        self.raw_weight = {'merek': 8, 'ram':5,'rom': 6, 
                           'baterai': 4, 'harga': 9}

    @property
    def weight(self):
        total_weight = sum(self.raw_weight.values())
        return {k: round(v/total_weight, 2) for k, v in self.raw_weight.items()}

    @property
    def data(self):
        query = select(hp.no, hp.nama_hp, hp.merek, hp.ram,
                       hp.rom, hp.baterai, hp.harga)
        result = session.execute(query).fetchall()
        return [{'no': hp.no,'nama_hp': hp.nama_hp, 'merek': hp.merek,
                'ram': hp.ram, 'rom': hp.rom, 'baterai': hp.baterai, 'harga': hp.harga} for hp in result]

    @property
    def normalized_data(self):
        # x/max [benefit]
        # min/x [cost]
        merek_values = []  # max
        ram_values = []  # max
        rom_values = []  # max
        baterai_values = []  # max
        harga_values = []  # min


        for data in self.data:
            # merek
            merek_cleaned = ''.join(
                char for char in data['merek'] if char.isdigit())
            merek_values.append(float(merek_cleaned)
                                if merek_cleaned else 0)  # Convert to float
            
            # ram
            ram_spec = data['ram']
            numeric_values = [int(value.split()[0]) for value in ram_spec.split(
                ',') if value.split()[0].isdigit()]
            max_ram_value = max(numeric_values) if numeric_values else 1
            ram_values.append(max_ram_value)

            # rom
            rom_spec = data['rom']
            rom_numeric_values = [int(
                value.split()[0]) for value in rom_spec.split() if value.split()[0].isdigit()]
            max_rom_value = max(
                rom_numeric_values) if rom_numeric_values else 1
            rom_values.append(max_rom_value)

            # baterai
            baterai_spec = data['baterai']
            baterai_numeric_values = [
                int(value) for value in baterai_spec.split() if value.isdigit()]
            max_baterai_value = max(
                baterai_numeric_values) if baterai_numeric_values else 1
            baterai_values.append(max_baterai_value)

            # harga
            harga_value = DEV_SCALE['harga'].get(data['harga'], 1)
            harga_values.append(harga_value)

        return [
            {'no': data['no'],
        'merek': min(merek_values) / max(merek_values) if max(merek_values) != 0 else 0,
        'ram': ram_value / max(ram_values),
        'rom': rom_value / max(rom_values),
        'baterai': baterai_value / max(baterai_values),
        'harga': harga_value / max(harga_values)
             }
            for data, merek_value, ram_value, rom_value, baterai_value, harga_value
    in zip(self.data, merek_values, ram_values, rom_values, baterai_values, harga_values)
        ]


class WeightedProduct(BaseMethod):
    @property
    def calculate(self):
        normalized_data = self.normalized_data
        produk = [
            {
                'no': row['no'],
                'produk': row['merek']**self.weight['merek'] *
                row['ram']**self.weight['ram'] *
                row['rom']**self.weight['rom'] *
                row['baterai']**self.weight['baterai'] *
                row['harga']**self.weight['harga']
            }
            for row in normalized_data
        ]
        sorted_produk = sorted(produk, key=lambda x: x['produk'], reverse=True)
        sorted_data = [
            {
                'no': product['no'],
                'merek': product['produk'] / self.weight['merek'],
                'ram': product['produk'] / self.weight['ram'],
                'rom': product['produk'] / self.weight['rom'],
                'baterai': product['produk'] / self.weight['baterai'],
                'harga': product['produk'] / self.weight['harga'],
                'score': product['produk']  # Nilai skor akhir
            }
            for product in sorted_produk
        ]
        return sorted_data


class SimpleAdditiveWeighting(BaseMethod):
    @property
    def calculate(self):
        weight = self.weight
        result = {row['no']:
                  round(row['merek'] * weight['merek'] +
                        row['ram'] * weight['ram'] +
                        row['rom'] * weight['rom'] +
                        row['baterai'] * weight['baterai'] +
                        row['harga'] * weight['harga'], 2)
                  for row in self.normalized_data
                  }
        sorted_result = dict(
            sorted(result.items(), key=lambda x: x[1], reverse=True))
        return sorted_result


def run_saw():
    saw = SimpleAdditiveWeighting()
    result = saw.calculate
    print(tabulate(result.items(), headers=['No', 'Score'], tablefmt='pretty'))


def run_wp():
    wp = WeightedProduct()
    result = wp.calculate
    headers = result[0].keys()
    rows = [
        {k: round(v, 4) if isinstance(v, float) else v for k, v in val.items()}
        for val in result
    ]
    print(tabulate(rows, headers="keys", tablefmt="grid"))


if __name__ == "__main__":
    if len(sys.argv) > 1:
        arg = sys.argv[1]

        if arg == 'create_table':
            create_table()
        elif arg == 'saw':
            run_saw()
        elif arg == 'wp':
            run_wp()
        else:
            print('command not found')
